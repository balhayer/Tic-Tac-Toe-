# Tic-Tac-Toe

Link to video : <https://www.youtube.com/watch?v=SWhJajpVZ84>

Author: Randy Le <br>
Author's Email: 97Randy.le@gmail.com <br>

## Summary
A swift game that focuses on IBAction and IBEvent. A 2 player game that requires one player to win by getting 3 X's or O's in a row to win.

## Features
* Displays whos turn it is
* Displays if theres a winner
* Reset button that clears the board

